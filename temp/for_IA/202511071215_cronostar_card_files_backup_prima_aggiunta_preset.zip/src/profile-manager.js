/**
 * Profile management for CronoStar Card
 * @module profile-manager
 */

import { Logger, safeParseFloat } from './utils.js';
import { TIMEOUTS } from './config.js';

export class ProfileManager {
  constructor(card) {
    this.card = card;
    this.lastLoadedProfile = "";
  }

  /**
   * Wait for entity to reach expected state
   * @param {string} entityId - Entity ID
   * @param {string} expectedState - Expected state
   * @param {number} timeoutMs - Timeout in ms
   * @returns {Promise}
   */
  async waitForEntityState(entityId, expectedState, timeoutMs = TIMEOUTS.entityStateWait) {
    const start = Date.now();
    
    return new Promise((resolve, reject) => {
      const check = () => {
        const current = this.card.hass?.states?.[entityId]?.state;
        
        if (current === expectedState) {
          resolve();
          return;
        }
        
        if (Date.now() - start > timeoutMs) {
          reject(new Error(`Timeout waiting for ${entityId} to become '${expectedState}', current: '${current}'`));
          return;
        }
        
        setTimeout(check, 100);
      };
      check();
    });
  }

  /**
   * Save current profile
   * @param {string} profileName - Profile name
   * @returns {Promise}
   */
  async saveProfile(profileName = this.lastLoadedProfile) {
    if (!profileName) {
      Logger.warn('SAVE', "No profile specified");
      throw new Error("No profile specified for saving");
    }

    const scriptName = this.card.config.save_script.startsWith('script.')
      ? this.card.config.save_script.substring(7)
      : this.card.config.save_script;

    Logger.info('SAVE', `Invoking script '${scriptName}' for profile '${profileName}'`);
    Logger.info('SAVE', `Parameters: entity_prefix='${this.card.config.entity_prefix}', hour_base=${this.card.hourBase}`);
    Logger.info('SAVE', `Data to save: ${JSON.stringify(this.card.stateManager.scheduleData)}`);

    try {
      await this.card.hass.callService("script", scriptName, {
        profile_name: profileName,
        entity_prefix: this.card.config.entity_prefix,
        hour_base: this.card.hourBase,
        payload_version: 2,
      });

      this.card.hasUnsavedChanges = false;
      this.lastLoadedProfile = profileName;
      Logger.info('SAVE', `Script '${scriptName}' completed for profile '${profileName}'`);
    } catch (err) {
      Logger.error('SAVE', `Error calling save script '${scriptName}':`, err);
      alert(`Error saving profile '${profileName}'. Check console for details.`);
      throw err;
    }
  }

  /**
   * Load profile
   * @param {string} profileName - Profile name
   * @returns {Promise}
   */
  async loadProfile(profileName) {
    this.card.stateManager.isLoadingProfile = true;
    
    const preLoadData = [...this.card.stateManager.scheduleData];
    Logger.info('LOAD', `PRE-load schedule data (00..05):`, preLoadData.slice(0, 6));

    const scriptName = this.card.config.load_script.startsWith('script.')
      ? this.card.config.load_script.substring(7)
      : this.card.config.load_script;

    Logger.info('LOAD', `Invoking script '${scriptName}' for profile '${profileName}'`);
    Logger.info('LOAD', `Parameters: entity_prefix='${this.card.config.entity_prefix}', hour_base=${this.card.hourBase}`);

    try {
      await this.card.hass.callService("script", scriptName, {
        profile_name: profileName,
        entity_prefix: this.card.config.entity_prefix,
        hour_base: this.card.hourBase,
        payload_version: 2,
      });

      Logger.info("LOAD", "Script completed, waiting for state propagation...");
      await new Promise(resolve => setTimeout(resolve, TIMEOUTS.statePropagation));

      // Force read updated values
      const newData = [];
      for (let hour = 0; hour < 24; hour++) {
        const entityId = this.card.stateManager.getEntityIdForHour(hour);
        const stateObj = this.card.hass.states[entityId];
        let newValue = stateObj ? safeParseFloat(stateObj.state) : null;
        newData[hour] = newValue;
        Logger.info('LOAD', `Loaded from hass: ${entityId} -> ${newValue}`);
      }

      Logger.info('LOAD', `POST-load values read (00..05):`, newData.slice(0, 6));
      Logger.info('LOAD', `POST-load values read (10..15):`, newData.slice(10, 16));

      // Log differences
      for (let i = 0; i < 24; i++) {
        if (preLoadData[i] !== newData[i]) {
          Logger.debug('DIFF', `idx=${i} hour=${this.card.stateManager.getHourLabel(i)}: ${preLoadData[i]} -> ${newData[i]}`);
        }
      }

      // Update state
      this.card.stateManager.setData(newData);

      // Update chart if initialized
      if (this.card.chartManager && this.card.chartManager.isInitialized()) {
        this.card.chartManager.updateData(newData);
        Logger.info("LOAD", "Chart updated with new data");
      }

      this.card.hasUnsavedChanges = false;
      this.lastLoadedProfile = profileName;
      Logger.info('LOAD', `Profile '${profileName}' loaded completely`);

    } catch (err) {
      Logger.error('LOAD', `Error calling load script '${scriptName}':`, err);
      alert(`Error loading profile '${profileName}'. Check console for details.`);
      throw err;
    } finally {
      this.card.stateManager.isLoadingProfile = false;
    }
  }

  /**
   * Handle profile selection change
   * @param {Event} e - Selection event
   */
  async handleProfileSelection(e) {
    this.card.suppressClickUntil = Date.now() + TIMEOUTS.menuSuppression + 500;
    
    // Snapshot selection for restoration
    if (this.card.selectionManager) {
      this.card.selectionManager.snapshotSelection();
    }

    const newProfile = e?.target?.value || e?.detail?.value || '';
    if (!newProfile) return;

    if (newProfile === '__ADD_NEW__') {
      this.createNewProfile();
      // Reset the selector back to the previously selected profile
      e.target.value = this.card.selectedProfile;
      return;
    }

    if (newProfile === this.card.selectedProfile) {
      return;
    }

    const previousProfile = this.lastLoadedProfile || this.card.selectedProfile;

    // Auto-save previous profile if changes exist
    if (this.card.hasUnsavedChanges && previousProfile) {
      try {
        Logger.info('SAVE', `Auto-saving previous profile '${previousProfile}' before switching`);
        await this.card.stateManager.ensureValuesApplied();
        this.card.stateManager.logPersistedValues(
          `auto-save profile '${previousProfile}'`,
          Array.from(this.card.stateManager.dirtyIndices)
        );
        await this.saveProfile(previousProfile);
        Logger.info('SAVE', `Auto-save of '${previousProfile}' completed`);
      } catch (err) {
        Logger.error('SAVE', "Error during auto-save:", err);
      }
    }

    // Update profile selector
    this.card.selectedProfile = newProfile;
    try {
      await this.card.hass.callService("input_select", "select_option", {
        entity_id: this.card.config.profiles_select_entity,
        option: newProfile,
      });
      await this.waitForEntityState(this.card.config.profiles_select_entity, newProfile, TIMEOUTS.entityStateWait);
    } catch (err) {
      Logger.warn('LOAD', "select_option or wait failed:", err);
    }

    // Load new profile
    try {
      await this.loadProfile(newProfile);
      
      // Restore selection
      if (this.card.selectionManager) {
        this.card.selectionManager.restoreSelectionFromSnapshot();
      }
      
      this.card.suppressClickUntil = Date.now() + TIMEOUTS.clickSuppression;
    } catch (err) {
      Logger.error('LOAD', "Error during auto-load:", err);
    }
  }

  async createNewProfile() {
    const newProfileName = prompt("Enter the name for the new profile:");
    if (!newProfileName || newProfileName.trim() === '') {
      Logger.info('PROFILE', 'Profile creation cancelled.');
      return;
    }

    const selectEntity = this.card.config.profiles_select_entity;
    const currentOptions = this.card.hass.states[selectEntity]?.attributes?.options || [];

    if (currentOptions.includes(newProfileName)) {
      alert(`Profile "${newProfileName}" already exists.`);
      return;
    }

    // Generate required YAML
    const slug = newProfileName.trim().toLowerCase().replace(/\s+/g, '_');
    const selectEntityId = this.card.config.profiles_select_entity.split('.')[1];
    const textEntityPrefix = selectEntityId.endsWith('s') ? selectEntityId.slice(0, -1) : selectEntityId;
    const textEntityId = `${textEntityPrefix}_${slug}`;

    const yaml = `input_text:\n  ${textEntityId}:\n    name: "Profile ${newProfileName.trim()} (JSON)"\n    max: 255`;

    const instructions = `
1. Copy the YAML below and add it to your configuration.yaml.

2. Go to Developer Tools > YAML and click "RELOAD INPUT TEXTS".

3. Once reloaded, click OK to save this profile.
    `;

    if (prompt(instructions, yaml) !== null) {
      try {
        // Add option to input_select
        const newOptions = [...currentOptions, newProfileName];
        await this.card.hass.callService('input_select', 'set_options', {
          entity_id: selectEntity,
          options: newOptions,
        });

        // Select the new option
        await this.card.hass.callService('input_select', 'select_option', {
          entity_id: selectEntity,
          option: newProfileName,
        });

        // Save the current schedule to this new profile
        await this.saveProfile(newProfileName);

        alert(`Profile "${newProfileName}" saved successfully.`);
      } catch (err) {
        Logger.error('PROFILE', `Failed to save new profile:`, err);
        alert(`Error saving profile "${newProfileName}". This may be because the input_text helper was not created or reloaded correctly. Check the console for details.`);
      }
    }
  }

  /**
   * Reset changes (reload current profile)
   */
  async resetChanges() {
    const profileToReload = this.lastLoadedProfile || this.card.selectedProfile;
    if (!profileToReload) {
      Logger.warn('LOAD', "No profile to reload");
      return;
    }

    if (this.card.selectionManager) {
      this.card.selectionManager.snapshotSelection();
    }

    try {
      await this.loadProfile(profileToReload);
      
      if (this.card.selectionManager) {
        this.card.selectionManager.restoreSelectionFromSnapshot();
      }
    } catch (err) {
      Logger.error('LOAD', "Error while reloading profile:", err);
    }
  }
}
